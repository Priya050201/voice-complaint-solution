document.addEventListener('DOMContentLoaded', () => {
const form = document.querySelector('#form');
const name = document.getElementById('name');
const number = document.querySelector('#number');
const email = document.querySelector('#email');
const password = document.querySelector('#psw');
const rp = document.querySelector('#psw-repeat');
form.addEventListener('submit', (e) => {
	e.preventDefault();
	validateInputs();
});
function validateInputs() {
	const nameval = name.value.trim();
	const numval = number.value.trim();
	const mailval = email.value.trim();
	const pwval = password.value.trim();
	const rpval = rp.value.trim();
	let isValid = true;
	if (nameval === '') {
		setError(name, 'Name is required');
		isValid = false;
	}
	else {
		setSuccess(name);
	}
	if (mailval === '') {
		setError(email, 'Email is required');
		isValid = false;
	}
	else if (!validateEmail(mailval)) {
		setError(email, 'Please enter valid email');
		isValid = false;
	}
	else {
		setSuccess(email);
	}
	if (numval === '') {
		setError(number, 'Number is required');
		isValid = false;
	}
	else if (!validatenum(numval)) {
		setError(number, 'Please enter valid number');
		isValid = false;
	}
	else {
		setSuccess(number);
	}
	if (pwval === '') {
		setError(password, 'Password is required');
		isValid = false;
	}
	else if (pwval.length < 8) {
		setError(password, 'Password must contain atleast 8 characters');
		isValid = false;
	}
	else {
		setSuccess(password);
	}
	if (rpval === '') {
		setError(rp, 'Password confirmation is must');
		isValid = false;
	}
	else if (rpval !== pwval) {
		setError(rp, 'Password does not match');
		isValid = false;
	}
	else {
		setSuccess(rp);
	}
	if(isValid){
		console.log('Successfully validated');
		form.submit();
	}

}
function setError(element, message) {
	const ipgrp = element.parentElement;
	const err = ipgrp.querySelector('.error');
	err.innerText = message;
	ipgrp.classList.add('error');
	ipgrp.classList.remove('success');
}
function setSuccess(element) {
	const ipgrp = element.parentElement;
	const err = ipgrp.querySelector('.error');
	err.innerText = '';
	ipgrp.classList.add('success');
	ipgrp.classList.remove('error');
}
const validateEmail = (email) => {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};
const validatenum = (number) => {
	return /^[0-9]{10}$/.test(number);
};
});
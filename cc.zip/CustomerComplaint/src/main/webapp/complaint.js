const form = document.getElementById('form');
const name = document.getElementById('fir');
const mail = document.querySelector('#email');
const dt = document.getElementById('dis');
const pin = document.querySelector('#zip');
const repdate = document.getElementById('dor');
const inciloc = document.getElementById('incloc');
const comtit = document.querySelector('#comtit');
const comdesc = document.getElementById('comdet');
const sev = document.querySelector('#sev');
const img = document.getElementById('img');
const aud = document.querySelector('.file');
const desout = document.getElementById('desout');
const sign = document.querySelector('.fil');

form.addEventListener('submit', (e) => {
	e.preventDefault();
	console.log("Form submitted");
	validateInputs();
});
function validateInputs() {
	const nameval = name.value.trim();
	const mailval = mail.value.trim();
	const dtval = dt.value.trim();
	const pinval = pin.value.trim();
	const repdateval = repdate.value.trim();
	const incilocval = inciloc.value.trim();
	const comtitval = comtit.value.trim();
	const comdescval = comdesc.value.trim();
	const sevval = sev.value.trim();
	const imgval = img.files.length;
	const audval = aud.files.length;
	const desoutval = desout.value.trim();
	const signval = sign.files.length;
	const today = new Date().toISOString().split('T')[0];

	console.log({
		nameval, mailval, dtval, pinval, repdateval,
		incilocval, comtitval, comdescval, sevval,
		imgval, audval, desoutval, signval
	});
	let valid = true;
	if (nameval === '') {
		setError(name, 'Name must be filled');
		valid =false;
	}
	else {
		setSuccess(name);
	}
	if (mailval === '') {
		setError(mail, 'Mail must be filled');
		valid = false;
	}
	else if (!validateEmail(mailval)) {
		setError(mail, 'Mail must be in correct format');
		valid = false;
	}
	else {
		setSuccess(mail);
	}
	if (dtval === '') {
		setError(dt, 'Select district');
		valid = false;
	}
	else {
		setSuccess(dt);
	}
	if (pinval === '') {
		setError(pin, 'pincode is must');
		valid = false;
	}
	else if (pinval.length < 6) {
		setError(pin, 'Pincode must be in 6 digits');
		valid = false;
	}
	else {
		setSuccess(pin);
	}
	if (repdateval === '') {
		setError(repdate, 'Reported date is needed');
		valid = false;
	}
	else if (repdateval > today) {
		setError(repdate, 'Reported date is invalid');
		valid = false;
	}
	else {
		setSuccess(repdate);
	}
	if (incilocval === '') {
		setError(inciloc, 'Incident location must be mentioned');
		valid = false;
	}
	else {
		setSuccess(inciloc);
	}
	if (comtitval === '') {
		setError(comtit, 'Complaint title must be mentioned');
		valid = false;
	}
	else {
		setSuccess(comtit);
	}
	if (comdescval === '') {
		setError(comdesc, 'complaint description is must');
		valid = false;
	}
	else {
		setSuccess(comdesc);
	}
	if (sevval === '') {
		setError(sev, 'Severity is must to understand the situation');
		valid = false;
	}
	else {
		setSuccess(sev);
	}
	if (imgval === 0) {
		setError(img, 'Image is must');
		valid = false;
	}
	else {
		setSuccess(img);
	}
	if (audval === 0) {
		setError(aud, 'Audio is must');
		valid = false;
	}
	else {
		setSuccess(aud);
	}
	if (desoutval === '') {
		setError(desout, 'Output description is must');
		valid = false;
	}
	else {
		setSuccess(desout);
	}
	if (signval === 0) {
		setError(sign, 'Signature is must');
		valid = false;
	}
	else {
		setSuccess(sign);
	}
	if(valid){
		window.location.href='ticket.html';
	}

}
function setError(element, message) {
	const ipgrp = element.parentElement;
	const err = ipgrp.querySelector('.error');
	err.innerText = message;
	ipgrp.classList.add('error');
	ipgrp.classList.remove('success');
}
function setSuccess(element) {
	const ipgrp = element.parentElement;
	const err = ipgrp.querySelector('.error');
	err.innerText = ' ';
	ipgrp.classList.add('success');
	ipgrp.classList.remove('error');
}
const validateEmail = (mail) => {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail);
};
